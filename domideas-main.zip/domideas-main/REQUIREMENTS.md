# DOMideas - In-App Visual Designer Mode

## Project Overview

A self-contained, framework-agnostic visual editing layer that allows designers and stakeholders to make UI changes directly in the browser and export AI-optimized diffs for implementation by AI coding agents (like Claude Code).

**Core Innovation:** Creates a visual-to-code translation layer optimized for AI consumption, enabling a seamless feedback loop between designers and AI development agents.

---

## Problem Statement

### Current Workflow (Broken):
1. Designer reviews UI in browser
2. Takes screenshots, annotates in Figma/Slack
3. Writes text descriptions of changes
4. Developer interprets and implements
5. Designer reviews again (repeat if wrong)

**Pain Points:**
- Lost in translation between visual feedback and code
- Time-consuming back-and-forth
- Ambiguous descriptions ("make it bigger", "more spacing")
- Difficult for non-technical stakeholders to give precise feedback

### New Workflow (DOMideas):
1. Designer/Stakeholder activates Designer Mode (?designer=true or Ctrl+Shift+D)
2. Clicks elements and modifies styles visually
3. Adds comments/annotations as needed
4. Generates AI-optimized diff with component context
5. Pastes diff into Claude Code
6. AI interprets structured diff and updates source code
7. Designer reviews (faster iteration cycle)

**Benefits:**
- Visual changes translate to precise code instructions
- No ambiguity - AI knows exactly what changed
- Component-aware (knows if changing design system vs page-specific)
- Non-technical stakeholders can participate
- Faster feedback loops

---

## Related Documentation

This document focuses on the core DOMideas product requirements. See also:

- **[document-index.md](./document-index.md)** - Central registry of ALL documentation
  - Complete list of all documents
  - Cross-reference map
  - Document status tracking

- **[claude.md](./claude.md)** - Instructions for AI agents and doc maintenance
  - How to maintain documentation consistency
  - Git workflow and commit guidelines
  - Project-specific conventions

- **[WEBSITE_REQUIREMENTS.md](./WEBSITE_REQUIREMENTS.md)** - Marketing website specifications
  - Target audience and messaging
  - Website structure and content
  - SEO and conversion optimization
  - Development phases for the marketing site

- **[PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md)** - Technical architecture
  - File structure and module organization
  - API specifications
  - Data flow diagrams
  - Build and deployment strategy

- **[BACKLOG.md](./BACKLOG.md)** - Future feature ideas
  - 94+ feature ideas organized by category
  - Prioritization framework
  - Roadmap beyond MVP (v2.0 - v5.0)
  - Experimental and moonshot ideas

---

## Core Features (MVP v1.0)

### 1. Activation & Security
- **Trigger Methods:**
  - URL query parameter: `?designer=true`
  - Keyboard shortcut: `Ctrl+Shift+D` (or `Cmd+Shift+D` on Mac)
  - Persistent mode via localStorage

- **Access Control:**
  - User authentication required
  - Role-based authorization (designer, admin roles only)
  - Environment gating (disabled in production by default)
  - No external dependencies (self-contained)

### 2. Visual Editing Layer
- **Non-intrusive overlay** that sits on top of existing UI
- **Element selection:**
  - Hover to preview selection
  - Click to select element
  - Visual highlight/outline on selected elements

- **Style editing panel** (right sidebar):
  - Colors (background, text, border)
  - Spacing (padding, margin)
  - Typography (font-size, weight, line-height)
  - Layout properties (flexbox alignment)
  - Border & shadows

- **Live preview** of changes without modifying source code
- **Reversible changes** (can reset/undo)

### 3. Component Intelligence
- **Framework Detection:**
  - React component detection via React DevTools hooks
  - Vue component detection via Vue internals
  - Svelte, Angular support (future)

- **Governance Classification:**
  - **GOVERNED:** Design system components (Button, Card, etc.)
  - **SHARED:** Reusable components (used 5+ times)
  - **LOCAL:** Page-specific elements

- **Detection Heuristics:**
  - Component name patterns (Button, Card, DS*, UI*)
  - Class name patterns (MuiButton, ds-, ui-, ant-)
  - Reuse frequency on page
  - Data attributes (data-component, data-testid)
  - Source file path hints

- **Governance Warnings:**
  - Alert user when editing governed components
  - Explain impact (affects all instances site-wide)
  - Suggest appropriate workflow (separate PR for design system)

### 4. Comment/Annotation System
- **Pin comments** to specific elements
- **Free-form text** (no structured categories in v1)
- **Visual markers** on page showing comment locations
- **Comments included in diff** with element context

### 5. AI-Optimized Diff Generation
- **Structured markdown format** for AI consumption
- **Rich context per change:**
  - Element selector (CSS selector)
  - Component information (name, framework, file path)
  - Governance level (GOVERNED/SHARED/LOCAL)
  - Before/after values
  - Visual location description
  - AI-specific instructions for implementation

- **Grouped by risk level:**
  - 🔴 Governed component changes (requires review)
  - 🟡 Shared component changes (moderate impact)
  - 🟢 Page-specific changes (safe to apply)

- **Export options:**
  - Copy to clipboard (paste into Claude Code)
  - Download as .md file
  - Future: Auto-create GitHub issue/PR

### 6. Design Token Awareness (Nice-to-have for v1)
- Detect CSS custom properties (CSS variables)
- Suggest using tokens instead of hard-coded values
- Example: "You changed to #3b82f6 - did you mean var(--color-primary)?"

---

## Technical Architecture

### Technology Stack
- **Core:** Vanilla JavaScript/TypeScript (no framework dependencies)
- **Optional:** GrapesJS for advanced drag-and-drop (v2+)
- **Storage:** localStorage for session persistence
- **Framework Integration:** Hooks into React DevTools, Vue internals

### File Structure
```
src/lib/designer-mode/
├── index.ts                 # Entry point, activation logic
├── overlay.ts               # Main overlay UI controller
├── components/
│   ├── toolbar.ts           # Top toolbar component
│   ├── style-panel.ts       # Right sidebar style editor
│   ├── selection-layer.ts   # Element selection handler
│   └── export-modal.ts      # Diff export UI
├── detection/
│   ├── component.ts         # React/Vue component detection
│   ├── governance.ts        # Governance level assessment
│   └── selector.ts          # CSS selector generation
├── diff/
│   ├── generator.ts         # Diff generation logic
│   ├── formatter.ts         # Markdown formatting
│   └── ai-instructions.ts   # AI-specific instruction generation
├── types.ts                 # TypeScript type definitions
└── styles.css               # Designer mode overlay styles
```

### Security Considerations
- **Content Security Policy (CSP):** Ensure designer mode doesn't violate CSP
- **No external scripts:** All code is self-contained and version-controlled
- **Role-based access:** Integrated with app's auth system
- **Environment gating:** Never enable in production (unless explicitly configured)
- **Iframe sandbox:** Not needed (we're not using iframes - direct DOM overlay)

### DOM Interaction Strategy
**Non-destructive editing:**
- Apply changes via inline styles temporarily
- Track changes in memory (ChangeRecord[])
- Original DOM remains intact
- Changes are reversible

**Overlay architecture:**
- Transparent layer with `pointer-events: none` (selectively enabled)
- Higher z-index than app content (z-index: 999999)
- Designer UI components have `pointer-events: auto`
- Clicking "through" overlay to select underlying elements

---

## Data Model

### ChangeRecord
```typescript
interface ChangeRecord {
  // Element identity
  selector: string;              // CSS selector
  elementType: string;           // 'button', 'div', etc.
  textContent: string;           // First 50 chars of text

  // Change details
  property: string;              // 'padding', 'backgroundColor', etc.
  originalValue: string;         // '8px 16px'
  newValue: string;              // '12px 24px'

  // Component context
  componentInfo: ComponentInfo;

  // Spatial context
  location: {
    section: string;             // 'header', 'main', 'footer'
    coordinates: { x: number; y: number };
  };

  // Metadata
  timestamp: number;
  comment?: string;              // Optional designer comment
}
```

### ComponentInfo
```typescript
interface ComponentInfo {
  framework: 'react' | 'vue' | 'svelte' | 'angular' | null;
  name: string | null;           // Component name
  file: string | null;           // Guessed file path
  governed: 'GOVERNED' | 'SHARED' | 'LOCAL';
  confidence: number;            // 0-100 confidence score
  signals: string[];             // Detection signals used
}
```

### DiffOutput (Markdown)
```markdown
# Design Feedback Session
**Generated:** [ISO timestamp]
**URL:** [Current URL]
**Page Title:** [Document title]
**Framework:** [Detected framework]

---

## 🔴 GOVERNED COMPONENT CHANGES

### Change #1: [Description]
**Component:** [Component name]
**File:** [File path]
**Governance:** GOVERNED
**Selector:** `[CSS selector]`
**Property:** [CSS property]
**Before:** `[original value]`
**After:** `[new value]`

**AI Instructions:**
```
[Specific code instructions for Claude Code]
```

**Impact Analysis:**
- Instances affected: [count]
- Accessibility: [impact]
- Responsive behavior: [notes]

---

[Repeat for each change, grouped by governance level]
```

---

## User Workflows

### Designer Workflow
1. Navigate to localhost:3000 in browser
2. Activate Designer Mode (Ctrl+Shift+D or add ?designer=true)
3. See overlay with toolbar appear
4. Click "Select" tool (or it's default)
5. Click element to edit
6. Style panel appears on right
7. Adjust colors, spacing, typography
8. See changes live
9. Optionally add comments to elements
10. Click "Export Diff" button
11. Copy markdown to clipboard
12. Paste into Claude Code chat
13. Wait for Claude Code to apply changes
14. Refresh page to see implemented changes
15. Iterate if needed

### Stakeholder Review Workflow (PM/Product)
1. Receive localhost URL with ?designer=true
2. Log in (authenticated as designer role)
3. Activate Designer Mode
4. Use "Comment" tool to add notes
5. No style editing (optional: restricted UI)
6. Export feedback diff
7. Send to developer or paste to Claude Code

### Developer Workflow
1. Receive design feedback diff (markdown)
2. Paste into Claude Code
3. Claude Code parses structured diff
4. Claude Code:
   - Identifies component files to modify
   - Respects governance levels
   - Creates separate PRs if needed (governed vs local)
   - Applies changes to source code
5. Developer reviews Claude's changes
6. Commits and pushes

---

## Integration Points

### Framework Integration

#### React
```typescript
// Detect React components
const fiber = element.__reactFiber$ || element.__reactInternalInstance$;
const componentName = fiber?.type?.name;
const componentFile = fiber?.type?._source?.fileName;
```

#### Vue
```typescript
// Detect Vue components
const vue = element.__vue__;
const componentName = vue?.$options?.name;
```

### AI Agent Integration (Claude Code)

**Input format:** Structured markdown with AI instructions

**Claude Code capabilities needed:**
- Parse markdown structure
- Extract component information
- Locate files in codebase
- Understand governance implications
- Generate appropriate code changes
- Handle multiple change types (CSS modules, styled-components, Tailwind, etc.)

**Example Claude Code prompt:**
```
I have design feedback from a visual editing session. Please parse the following
diff and apply the changes to the codebase. Pay attention to governance levels:
- GOVERNED changes should update design system components
- SHARED changes should update reusable components
- LOCAL changes should be scoped to specific pages

[Paste diff markdown here]
```

---

## MVP Scope (v1.0)

### In Scope:
- ✅ Basic element selection and highlighting
- ✅ Style editing panel (colors, spacing, typography)
- ✅ Component detection (React, Vue)
- ✅ Governance classification (GOVERNED/SHARED/LOCAL)
- ✅ Change tracking and recording
- ✅ AI-optimized markdown diff generation
- ✅ Copy to clipboard / download .md
- ✅ Basic comment/annotation system
- ✅ Authentication/authorization integration
- ✅ Environment gating (dev only)

### Out of Scope (v2+):
- ❌ Drag and drop element repositioning
- ❌ Add new elements from component library
- ❌ HTML structure editing (only CSS changes in v1)
- ❌ Undo/redo history
- ❌ Real-time collaboration (multi-user)
- ❌ Figma integration
- ❌ Auto-create GitHub issues/PRs
- ❌ Visual regression detection
- ❌ Responsive preview (multiple breakpoints)
- ❌ Accessibility scoring
- ❌ Design system token generation

---

## Success Metrics

### Usage Metrics:
- Number of designer mode sessions activated
- Number of diffs generated
- Number of changes per session
- Governance distribution (% GOVERNED vs SHARED vs LOCAL)

### Quality Metrics:
- Component detection accuracy
- Time from feedback to implementation (vs traditional workflow)
- Designer satisfaction (survey)
- AI agent success rate (% of diffs successfully applied by Claude Code)

### Technical Metrics:
- Performance impact on page load (<100ms overhead)
- Bundle size (<200KB for designer mode code)
- Browser compatibility (Chrome, Firefox, Safari, Edge)

---

## Future Enhancements (Post-MVP)

### v2.0 - Structural Editing
- Drag and drop element repositioning
- Add new elements from component palette
- HTML structure diffing (not just CSS)
- Visual component tree navigator

### v3.0 - Collaboration
- Real-time multi-user editing sessions
- Comment threads and discussions
- Voting on proposed changes
- Design review workflow (propose → review → approve)

### v4.0 - Intelligence
- AI-powered design suggestions
- Accessibility auto-fixes
- Design system compliance checking
- Pattern detection ("you've changed 5 buttons the same way")
- Bulk apply similar changes

### v5.0 - Integration
- Figma design comparison (design vs implementation)
- Auto-create GitHub issues/PRs from diffs
- Linear/Jira ticket integration
- Slack notifications for design reviews
- Visual regression testing integration

---

## Open Questions

1. **Component File Mapping:**
   - How accurate can we make file path detection without source maps?
   - Should we ask users to provide component-to-file mapping?
   - Build a server-side endpoint to scan filesystem?

2. **Design Token Detection:**
   - Parse CSS variables from :root?
   - Read from a config file (theme.ts, tailwind.config.js)?
   - Let designers manually define tokens?

3. **Diff Format:**
   - Is markdown the best format for AI consumption?
   - Should we also generate JSON for programmatic use?
   - Include screenshots/visual diffs?

4. **Persistence:**
   - Should we save draft sessions (localStorage)?
   - Allow multiple named sessions?
   - Sync to backend for team sharing?

5. **Production Use:**
   - Should this ever be enabled in production?
   - Use case: Stakeholder reviews staging environment
   - Security implications of allowing style modifications

---

## Getting Started (Implementation Phases)

> **Note:** You can work on the marketing website (Phase 0) in parallel with or before the product implementation. The website can help gather early feedback and validate market interest.

### Phase 0: Marketing Website (2 weeks) - **OPTIONAL FIRST STEP**

**Purpose:** Build market awareness and gather feedback before building the full product

**Week 1:**
- [ ] Set up Next.js project for marketing site
- [ ] Design system (Tailwind config, colors, typography)
- [ ] Landing page structure and navigation
- [ ] Responsive layout for all sections

**Week 2:**
- [ ] Write all copy (headlines, features, use cases)
- [ ] Create demo video (can be simple screen recording initially)
- [ ] Add email capture form (waitlist)
- [ ] Deploy to Vercel
- [ ] Basic analytics (PostHog or Plausible)

**Launch Criteria:**
- Landing page live with compelling messaging
- Demo video explaining the concept
- Email capture for waitlist
- Links to GitHub repo (with requirements docs)
- Mobile responsive

**Why Do This First:**
- Validate market interest before building product
- Gather email list of interested early adopters
- Force you to clarify messaging and positioning
- Get feedback on the concept
- Potential to attract contributors or investors

**See [WEBSITE_REQUIREMENTS.md](./WEBSITE_REQUIREMENTS.md) for complete specifications.**

---

### Phase 1: Core Infrastructure (Week 1)
- [ ] Set up project structure
- [ ] Implement activation logic (query param, hotkey)
- [ ] Create overlay root and basic toolbar
- [ ] Build selection layer (hover, click, highlight)

### Phase 2: Style Editing (Week 2)
- [ ] Build style panel UI
- [ ] Implement color picker
- [ ] Implement spacing controls
- [ ] Implement typography controls
- [ ] Wire up change tracking

### Phase 3: Component Detection (Week 3)
- [ ] React component detection
- [ ] Vue component detection
- [ ] Governance assessment algorithm
- [ ] Selector generation
- [ ] File path guessing

### Phase 4: Diff Generation (Week 4)
- [ ] Change record data structure
- [ ] Markdown formatter
- [ ] AI instruction generator
- [ ] Export modal UI
- [ ] Copy to clipboard functionality

### Phase 5: Polish & Testing (Week 5)
- [ ] Authentication integration
- [ ] Environment gating
- [ ] Cross-browser testing
- [ ] Performance optimization
- [ ] Documentation

### Phase 6: AI Integration Testing (Week 6)
- [ ] Test with Claude Code
- [ ] Refine diff format based on AI feedback
- [ ] Add example diffs to documentation
- [ ] Create tutorial video/guide

---

## Related Projects & Inspiration

- **VisBug:** Chrome extension for visual debugging (inspiration)
- **Vercel Toolbar:** In-app developer toolbar
- **Sanity Visual Editing:** Content editing in-context
- **Builder.io:** Visual page builder
- **GrapesJS:** Open-source web builder framework
- **Framer:** Design tool with code output
- **Figma Dev Mode:** Design-to-code handoff

**What makes DOMideas unique:**
- Optimized for AI agent consumption (not human developers)
- Component governance awareness
- Works on live running apps (not static designs)
- Self-contained (no external service dependencies)

---

## License & Ownership

TBD - Define license for open source vs proprietary use

---

## Contact & Support

Project Lead: [Your name]
Repository: [GitHub URL when created]
Documentation: [Docs site URL]
Issues: [GitHub Issues URL]
