# DOMideas

**Visual design editing for the AI age**

A self-contained, in-app visual editing layer that allows designers and stakeholders to make UI changes directly in the browser and export AI-optimized diffs for implementation by AI coding agents like Claude Code.

---

## The Problem

Traditional design feedback workflow:
1. Designer reviews UI
2. Takes screenshots, annotates
3. Writes vague descriptions ("make it bigger", "needs more space")
4. Developer interprets and implements
5. Designer reviews again... (repeat)

**Result:** Slow, error-prone, frustrating for everyone.

---

## The Solution

DOMideas creates a direct visual-to-code pipeline:

1. **Designer** activates Designer Mode in browser
2. **Clicks elements** and modifies styles visually
3. **Generates AI-optimized diff** with full context
4. **Pastes into Claude Code** (or similar AI agent)
5. **AI applies changes** to source code automatically
6. **Done** - accurate implementation, no translation errors

---

## Key Features

### 🎨 Visual Editing
- Click any element to edit its styles
- Live preview of changes
- Intuitive style panel (colors, spacing, typography)
- Non-destructive (doesn't modify source code)

### 🧠 Component Intelligence
- Automatically detects React/Vue components
- Identifies design system components vs page-specific elements
- Warns when editing shared/governed components
- Suggests appropriate workflows (separate PR for design system changes)

### 🤖 AI-Optimized Output
- Generates structured markdown diffs
- Includes component information, file paths, governance level
- Provides specific code instructions for AI agents
- Groups changes by risk level (governed/shared/local)

### 🔒 Secure & Self-Contained
- No browser extension required
- Integrated with your app's auth system
- Environment-gated (dev/staging only)
- Version-controlled with your codebase

---

## Quick Start

### Installation

```bash
npm install domideas
# or
yarn add domideas
```

### Integration (React/Next.js)

```typescript
// app/layout.tsx or _app.tsx
import { DesignerMode } from 'domideas';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}

        {/* Only load in development */}
        {process.env.NODE_ENV === 'development' && <DesignerMode />}
      </body>
    </html>
  );
}
```

### Activation

**Method 1:** URL query parameter
```
http://localhost:3000?designer=true
```

**Method 2:** Keyboard shortcut
```
Ctrl+Shift+D (Windows/Linux)
Cmd+Shift+D (Mac)
```

---

## How It Works

### 1. Overlay Architecture

DOMideas creates a transparent editing layer on top of your existing UI. It doesn't modify your app's DOM - it just overlays controls and tracks changes in memory.

```
┌─────────────────────────────────────┐
│  Designer Overlay (z-index: 999999) │ ← Toolbar, style panel, highlights
├─────────────────────────────────────┤
│  Your App's UI                      │ ← Unchanged, untouched
└─────────────────────────────────────┘
```

### 2. Component Detection

When you select an element, DOMideas inspects it to understand what it is:

```typescript
// Detects React components
const fiber = element.__reactFiber$;
const componentName = fiber?.type?.name; // "Button"

// Assesses governance level
const governance = assessGovernance(element);
// → "GOVERNED" (design system component)
// → "SHARED" (reusable component)
// → "LOCAL" (page-specific element)
```

### 3. AI-Optimized Diff

When you export, DOMideas generates a structured markdown diff optimized for AI consumption:

```markdown
# Design Feedback Session

## 🔴 GOVERNED COMPONENT CHANGES

### Change #1: Primary Button Padding
**Component:** Button (Primary variant)
**File:** src/components/Button/Button.tsx
**Property:** padding
**Before:** `8px 16px`
**After:** `12px 24px`

**AI Instructions:**
Update Button component padding in theme configuration...

**Impact:** Affects all primary buttons site-wide (~150 instances)
```

---

## Documentation

**📍 Start Here:**
- **[Document Index](./document-index.md)** - Complete registry of all documentation
- **[Claude Instructions](./claude.md)** - For AI agents and contributors maintaining docs

**📋 Planning & Requirements:**
- **[Requirements](./REQUIREMENTS.md)** - Full project requirements and specifications
- **[Project Structure](./PROJECT_STRUCTURE.md)** - Architecture and file organization
- **[Website Requirements](./WEBSITE_REQUIREMENTS.md)** - Marketing website specifications
- **[Feature Backlog](./BACKLOG.md)** - 94+ future feature ideas

**🚀 Development (Future):**
- **[Getting Started](./docs/getting-started.md)** - Step-by-step implementation guide (planned)
- **[API Reference](./docs/api-reference.md)** - Complete API documentation (planned)
- **[Contributing](./CONTRIBUTING.md)** - Contribution guidelines (planned)

---

## Development Status

**Current Phase:** Requirements & Architecture ✅

**Next Steps:**
1. Core infrastructure implementation
2. React component detection
3. Basic style editing panel
4. Diff generation
5. Testing with Claude Code integration

See [REQUIREMENTS.md](./REQUIREMENTS.md) for detailed roadmap.

---

## Example Workflow

**Scenario:** Product manager reviewing dashboard on localhost

1. Opens `http://localhost:3000/dashboard?designer=true`
2. Activates Designer Mode (sees overlay)
3. Selects button, increases padding
4. Selects card, increases margin
5. Adds comment: "Make header bolder"
6. Exports diff (2 changes + 1 comment)
7. Pastes into Claude Code
8. Claude Code applies changes automatically
9. Refreshes to see implementation
10. **Total time: 5 minutes** (vs 30+ minutes traditional workflow)

---

## Framework Support

- ✅ React (16.8+)
- ✅ Next.js (12+)
- ✅ Vue 3
- ✅ Vanilla JavaScript
- 🚧 Vue 2, Svelte, Angular (planned)

---

## Browser Support

- Chrome/Edge: Latest 2 versions ✅
- Firefox: Latest 2 versions ✅
- Safari: Latest 2 versions ✅

---

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

---

## License

MIT © 2025

---

## Credits

Inspired by VisBug, Vercel Toolbar, and Sanity Visual Editing.

Built for designers, developers, and AI agents working together.

---

**Made with ❤️ for the AI-powered development workflow**
