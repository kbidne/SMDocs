# DOMideas Project Structure

This document outlines the recommended file structure for implementing DOMideas.

## Directory Layout

```
domideas/
├── src/
│   └── lib/
│       └── designer-mode/
│           ├── index.ts                    # Entry point & activation
│           ├── overlay.ts                  # Main overlay controller
│           │
│           ├── components/                 # UI Components
│           │   ├── toolbar.ts              # Top toolbar
│           │   ├── style-panel.ts          # Right sidebar editor
│           │   ├── selection-layer.ts      # Element selection
│           │   ├── comment-tool.ts         # Comment/annotation tool
│           │   └── export-modal.ts         # Diff export dialog
│           │
│           ├── detection/                  # Component detection
│           │   ├── framework.ts            # Detect React/Vue/etc
│           │   ├── component.ts            # Extract component info
│           │   ├── governance.ts           # Assess governance level
│           │   └── selector.ts             # Generate CSS selectors
│           │
│           ├── diff/                       # Diff generation
│           │   ├── generator.ts            # Main diff generator
│           │   ├── formatter.ts            # Markdown formatting
│           │   ├── ai-instructions.ts      # AI-specific instructions
│           │   └── templates.ts            # Markdown templates
│           │
│           ├── utils/                      # Utilities
│           │   ├── color.ts                # Color conversion (rgb→hex)
│           │   ├── storage.ts              # localStorage wrapper
│           │   └── dom.ts                  # DOM helper functions
│           │
│           ├── types.ts                    # TypeScript types
│           └── styles.css                  # Designer mode styles
│
├── examples/                               # Example integrations
│   ├── nextjs/                             # Next.js integration example
│   ├── react/                              # Create React App example
│   ├── vue/                                # Vue 3 example
│   └── vanilla/                            # Vanilla JS example
│
├── docs/                                   # Documentation
│   ├── getting-started.md
│   ├── integration-guide.md
│   ├── ai-agent-guide.md                   # Guide for AI agents
│   └── api-reference.md
│
├── tests/                                  # Tests
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── REQUIREMENTS.md                         # Project requirements
├── PROJECT_STRUCTURE.md                    # This file
├── README.md                               # Project overview
├── package.json
├── tsconfig.json
└── LICENSE
```

## Core Modules

### 1. `index.ts` - Entry Point
**Responsibilities:**
- Initialize designer mode
- Handle activation methods (query param, hotkey, localStorage)
- Check authentication & authorization
- Environment gating
- Load overlay on demand

**Public API:**
```typescript
export class DesignerMode {
  enable(): void
  disable(): void
  isEnabled(): boolean
  getCurrentUser(): Promise<User>
}
```

---

### 2. `overlay.ts` - Main Controller
**Responsibilities:**
- Create and manage overlay DOM
- Coordinate all sub-components
- Handle global event listeners
- Manage change tracking
- Orchestrate diff export

**Public API:**
```typescript
export class DesignerOverlay {
  mount(): void
  unmount(): void
  selectElement(element: HTMLElement): void
  exportDiff(): string
  getChanges(): ChangeRecord[]
}
```

---

### 3. Components

#### `toolbar.ts`
Top toolbar with tools and actions.

**Features:**
- Select tool (default)
- Comment tool
- Measure tool (future)
- Export diff button
- Exit designer mode button

#### `style-panel.ts`
Right sidebar with style editing controls.

**Features:**
- Element info display
- Color pickers (background, text, border)
- Spacing inputs (padding, margin)
- Typography controls (size, weight, line-height)
- Layout controls (flex, grid)
- Live preview of changes

#### `selection-layer.ts`
Transparent layer for element selection.

**Features:**
- Hover preview with outline
- Click to select
- Visual highlighting
- Element info tooltip
- Deselection handling

#### `comment-tool.ts`
Add comments/annotations to elements.

**Features:**
- Pin comment to element
- Visual marker on page
- Comment text input
- Edit/delete comments
- Include in diff export

#### `export-modal.ts`
Modal dialog for exporting diffs.

**Features:**
- Display generated diff
- Copy to clipboard button
- Download as .md file
- Change count summary
- Grouped by governance level

---

### 4. Detection

#### `framework.ts`
Detect which framework is being used.

**Functions:**
```typescript
detectFramework(): 'react' | 'vue' | 'svelte' | 'angular' | null
getReactVersion(): string | null
getVueVersion(): string | null
```

#### `component.ts`
Extract component information from DOM elements.

**Functions:**
```typescript
detectComponent(element: HTMLElement): ComponentInfo
getReactComponentName(element: HTMLElement): string | null
getVueComponentName(element: HTMLElement): string | null
guessComponentFile(componentName: string): string | null
```

#### `governance.ts`
Assess governance level of components.

**Functions:**
```typescript
assessGovernance(element: HTMLElement): GovernanceAssessment
isDesignSystemComponent(element: HTMLElement): boolean
countInstancesOnPage(element: HTMLElement): number
getGovernanceRecommendation(level: GovernanceLevel): string
```

#### `selector.ts`
Generate optimal CSS selectors for elements.

**Functions:**
```typescript
generateSelector(element: HTMLElement): string
generateUniqueSelector(element: HTMLElement): string
testSelector(selector: string): boolean
```

---

### 5. Diff Generation

#### `generator.ts`
Main diff generation orchestrator.

**Functions:**
```typescript
generateDiff(changes: ChangeRecord[]): string
groupByGovernance(changes: ChangeRecord[]): GroupedChanges
addMetadata(diff: string): string
```

#### `formatter.ts`
Format changes as markdown.

**Functions:**
```typescript
formatAsMarkdown(changes: ChangeRecord[]): string
formatChange(change: ChangeRecord, index: number): string
formatGovernedSection(changes: ChangeRecord[]): string
formatSharedSection(changes: ChangeRecord[]): string
formatLocalSection(changes: ChangeRecord[]): string
```

#### `ai-instructions.ts`
Generate AI-specific instructions.

**Functions:**
```typescript
generateInstructions(change: ChangeRecord): string
generateReactInstructions(change: ChangeRecord): string
generateVueInstructions(change: ChangeRecord): string
generateCSSInstructions(change: ChangeRecord): string
detectStyleMethod(component: ComponentInfo): 'styled-components' | 'css-modules' | 'tailwind' | 'vanilla'
```

#### `templates.ts`
Markdown templates for diff sections.

**Templates:**
```typescript
const DIFF_HEADER_TEMPLATE: string
const GOVERNED_CHANGE_TEMPLATE: string
const SHARED_CHANGE_TEMPLATE: string
const LOCAL_CHANGE_TEMPLATE: string
const COMMENT_TEMPLATE: string
const METADATA_TEMPLATE: string
```

---

### 6. Utilities

#### `color.ts`
Color format conversions.

**Functions:**
```typescript
rgbToHex(rgb: string): string
hexToRgb(hex: string): string
parseColor(color: string): { r: number; g: number; b: number; a?: number }
```

#### `storage.ts`
localStorage wrapper with type safety.

**Functions:**
```typescript
saveSession(changes: ChangeRecord[]): void
loadSession(): ChangeRecord[] | null
clearSession(): void
saveSetting(key: string, value: any): void
loadSetting(key: string): any
```

#### `dom.ts`
DOM helper utilities.

**Functions:**
```typescript
getElementPath(element: HTMLElement): string
getElementDescription(element: HTMLElement): string
getComputedStyles(element: HTMLElement): CSSStyleDeclaration
findSimilarElements(element: HTMLElement): HTMLElement[]
getPageSection(element: HTMLElement): 'header' | 'main' | 'footer' | 'sidebar' | 'unknown'
```

---

## TypeScript Types

### Core Types (`types.ts`)

```typescript
// Change tracking
export interface ChangeRecord {
  id: string;
  selector: string;
  elementType: string;
  textContent: string;
  property: string;
  originalValue: string;
  newValue: string;
  componentInfo: ComponentInfo;
  location: ElementLocation;
  timestamp: number;
  comment?: string;
}

// Component information
export interface ComponentInfo {
  framework: Framework | null;
  name: string | null;
  file: string | null;
  governed: GovernanceLevel;
  confidence: number;
  signals: string[];
}

export type Framework = 'react' | 'vue' | 'svelte' | 'angular';
export type GovernanceLevel = 'GOVERNED' | 'SHARED' | 'LOCAL';

// Governance assessment
export interface GovernanceAssessment {
  level: GovernanceLevel;
  confidence: number;
  signals: string[];
  recommendation: GovernanceRecommendation;
}

export interface GovernanceRecommendation {
  warning: string | null;
  action: string;
  suggestedWorkflow: string;
  aiInstruction: string;
}

// Location information
export interface ElementLocation {
  section: string;
  coordinates: { x: number; y: number };
  boundingBox: DOMRect;
}

// Grouped changes for diff export
export interface GroupedChanges {
  governed: ChangeRecord[];
  shared: ChangeRecord[];
  local: ChangeRecord[];
}

// User/auth types
export interface User {
  id: string;
  email: string;
  role: UserRole;
}

export type UserRole = 'designer' | 'developer' | 'admin' | 'viewer';

// Settings
export interface DesignerSettings {
  enabled: boolean;
  hotkey: string;
  persistSession: boolean;
  showGovernanceWarnings: boolean;
}
```

---

## Data Flow

### 1. Activation Flow
```
User triggers activation (query param / hotkey)
    ↓
DesignerMode.checkActivation()
    ↓
DesignerMode.requestAccess()
    ↓
Check authentication & authorization
    ↓
Check environment (not production)
    ↓
DesignerMode.enable()
    ↓
Load DesignerOverlay (code splitting)
    ↓
DesignerOverlay.mount()
    ↓
Create overlay DOM
    ↓
Initialize components (toolbar, selection layer, style panel)
    ↓
Designer Mode Active ✓
```

### 2. Element Selection Flow
```
User hovers over element
    ↓
SelectionLayer captures mousemove event
    ↓
SelectionLayer.getElementUnderCursor()
    ↓
SelectionLayer.highlightElement()
    ↓
User clicks element
    ↓
SelectionLayer.selectElement()
    ↓
DesignerOverlay.selectElement()
    ↓
Detect component info (framework, name, governance)
    ↓
StylePanel.show(element, componentInfo)
    ↓
Render style controls based on computed styles
    ↓
Element Selected ✓
```

### 3. Style Change Flow
```
User modifies style in panel (e.g., changes padding)
    ↓
StylePanel input event listener fires
    ↓
StylePanel.applyStyleChange(element, property, value)
    ↓
Apply inline style to element
    ↓
DesignerOverlay.recordChange()
    ↓
Create ChangeRecord with full context
    ↓
Detect component info
    ↓
Assess governance level
    ↓
Generate selector
    ↓
Add to DesignerOverlay.changes[]
    ↓
Change Tracked ✓
```

### 4. Diff Export Flow
```
User clicks "Export Diff" button
    ↓
DesignerOverlay.exportDiff()
    ↓
DiffGenerator.generateDiff(changes)
    ↓
Group changes by governance level
    ↓
For each change:
    ↓
    DiffFormatter.formatChange()
    ↓
    AIInstructions.generateInstructions()
    ↓
    Add to appropriate section (GOVERNED/SHARED/LOCAL)
    ↓
Add metadata (timestamp, URL, framework)
    ↓
Combine into final markdown
    ↓
ExportModal.show(markdown)
    ↓
User copies to clipboard or downloads
    ↓
Diff Exported ✓
```

---

## Styling Approach

### CSS Architecture

**Scoped styles** to avoid conflicts with host application:

```css
/* src/lib/designer-mode/styles.css */

/* Namespace all designer mode styles */
.designer-overlay-root {
  /* Container styles */
}

.designer-toolbar {
  /* Toolbar styles */
}

.designer-style-panel {
  /* Style panel styles */
}

/* Use CSS custom properties for theming */
:root {
  --designer-primary: #3b82f6;
  --designer-bg: #ffffff;
  --designer-border: #e5e7eb;
  --designer-text: #1f2937;
  --designer-z-index: 999999;
}

/* Dark mode support (optional) */
@media (prefers-color-scheme: dark) {
  :root {
    --designer-bg: #1f2937;
    --designer-text: #f9fafb;
    --designer-border: #374151;
  }
}
```

### Avoiding Conflicts

1. **High z-index** for overlay (999999)
2. **Namespaced class names** (all start with `designer-`)
3. **CSS reset** for overlay elements to ignore host styles
4. **No global styles** - all scoped to overlay
5. **Shadow DOM** (optional future enhancement for complete isolation)

---

## Build & Bundle

### Recommended Build Setup

**Option 1: Separate Bundle** (recommended)
```json
// package.json
{
  "scripts": {
    "build:designer": "vite build --config vite.designer.config.ts",
    "build:app": "vite build",
    "build": "npm run build:app && npm run build:designer"
  }
}
```

Bundle designer mode separately and load on-demand:
```typescript
// app/layout.tsx
if (process.env.NODE_ENV === 'development') {
  import('@/lib/designer-mode').then(module => {
    new module.DesignerMode();
  });
}
```

**Option 2: Code Splitting**
Use dynamic imports to load designer mode only when activated:
```typescript
// src/lib/designer-mode/index.ts
private async enable() {
  const { DesignerOverlay } = await import('./overlay');
  const overlay = new DesignerOverlay();
  overlay.mount();
}
```

### Bundle Size Targets
- Initial load: <10KB (activation logic only)
- Full designer mode: <200KB (all features loaded)
- Lazy-loaded chunks: <50KB each

---

## Testing Strategy

### Unit Tests
- Component detection accuracy
- Selector generation
- Governance assessment
- Color utilities
- Diff formatting

### Integration Tests
- Full activation flow
- Element selection and editing
- Change tracking
- Diff export

### E2E Tests
- Real browser testing (Playwright/Cypress)
- Test on sample apps (React, Vue)
- Cross-browser compatibility
- Performance benchmarks

### Manual Testing Checklist
- [ ] Activation via query param works
- [ ] Activation via hotkey works
- [ ] Element selection highlights correctly
- [ ] Style changes apply live
- [ ] Component detection identifies React components
- [ ] Component detection identifies Vue components
- [ ] Governance warnings appear for design system components
- [ ] Diff export includes all changes
- [ ] Diff markdown is valid
- [ ] Copy to clipboard works
- [ ] Download .md file works
- [ ] Exit designer mode cleans up properly
- [ ] Works in Chrome, Firefox, Safari
- [ ] Performance impact is minimal

---

## Development Workflow

### Local Development
1. Clone repo
2. Install dependencies: `npm install`
3. Run dev server: `npm run dev`
4. Navigate to `localhost:3000?designer=true`
5. Make changes to designer mode code
6. Hot reload updates automatically

### Adding a New Feature
1. Update requirements doc if scope changes
2. Create feature branch: `git checkout -b feature/new-tool`
3. Implement feature in appropriate module
4. Add TypeScript types to `types.ts`
5. Write tests
6. Update documentation
7. Create PR for review

### Release Process
1. Update version in `package.json`
2. Update CHANGELOG.md
3. Run full test suite: `npm test`
4. Build production bundle: `npm run build`
5. Tag release: `git tag v1.0.0`
6. Push to GitHub
7. Publish to npm (if open source): `npm publish`

---

## Integration Examples

See `examples/` directory for full integration examples with:
- Next.js (App Router & Pages Router)
- Create React App
- Vue 3
- Vanilla JavaScript

Each example includes:
- Installation instructions
- Configuration
- Authentication setup
- Custom styling
- Deployment notes

---

## Performance Considerations

### Optimization Strategies
1. **Lazy loading:** Don't load designer mode until activated
2. **Code splitting:** Split large modules into chunks
3. **Debouncing:** Debounce style change events (avoid excess recording)
4. **Event delegation:** Use event delegation instead of per-element listeners
5. **RequestAnimationFrame:** Use RAF for smooth highlighting/selection
6. **Memoization:** Cache computed styles, selectors, component info
7. **Virtual scrolling:** For large style panels with many controls (future)

### Performance Budgets
- Time to activate: <500ms
- Time to select element: <100ms
- Time to open style panel: <200ms
- Time to apply style change: <50ms
- Time to export diff: <1000ms
- Memory overhead: <50MB

---

## Security Checklist

- [ ] Never enable in production (unless explicitly configured)
- [ ] Require authentication before activation
- [ ] Check user role/permissions
- [ ] No external script loading (self-contained)
- [ ] Validate all user inputs (color values, spacing values)
- [ ] Sanitize exported markdown (no XSS vectors)
- [ ] CSP compliant (no inline scripts if CSP strict)
- [ ] No localStorage of sensitive data
- [ ] Rate limiting on diff generation (prevent abuse)

---

## Browser Compatibility

### Target Browsers
- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions

### Required Features
- ES6+ (async/await, classes, arrow functions)
- CSS Grid & Flexbox
- CSS Custom Properties
- localStorage
- Clipboard API
- ResizeObserver (polyfill if needed)

### Polyfills
Include polyfills for:
- `Object.fromEntries` (Safari 12)
- `String.prototype.replaceAll` (older browsers)
- Clipboard API (Firefox < 63)

---

This structure provides a solid foundation for implementing DOMideas. Adjust as needed based on your specific framework and requirements.
