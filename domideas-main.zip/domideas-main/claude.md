# Claude Code Instructions for DOMideas Project

**Last Updated:** 2025-11-15

---

## Project Overview

**DOMideas** is a self-contained, in-app visual editing layer that allows designers and stakeholders to make UI changes directly in the browser and export AI-optimized diffs for implementation by AI coding agents (like Claude Code).

**Core Innovation:** Creates a visual-to-code translation layer optimized for AI consumption, enabling a seamless feedback loop between designers and AI development agents.

**Current Status:** Requirements & Planning Phase
**Next Phase:** Marketing Website Development (Parallel with Product Development)

---

## Documentation System

This project uses a **self-maintaining documentation system** to ensure coherence across multiple AI sessions and human contributors.

### Core Principle: Documents Must Stay in Sync

When you modify one document, you MUST update related documents to maintain consistency. This is critical for long-running projects with multiple contributors and AI sessions.

---

## 🚨 CRITICAL INSTRUCTIONS: Documentation Maintenance

### When You Create a New Document

**MANDATORY STEPS (Execute in this order):**

1. **Create the new document** with appropriate content
2. **Update document-index.md** to include the new document:
   - Add entry with filename, description, last updated date
   - Add to appropriate category
   - Update document count
3. **Update related documents** that should reference the new document:
   - Add cross-reference links where relevant
   - Update "Related Documentation" sections
   - Ensure bidirectional linking (if A links to B, B should link to A when relevant)
4. **Update this file (claude.md)** if the new document changes workflows or processes
5. **Commit all changes together** in a single atomic commit

### When You Modify an Existing Document

**MANDATORY STEPS:**

1. **Make your changes** to the document
2. **Update document-index.md**:
   - Update the "Last Updated" timestamp for that document
   - Update the description if the purpose changed
3. **Review related documents**:
   - Check if cross-references need updating
   - Update any documents that quote or reference the modified content
4. **Update this file (claude.md)** if the changes affect workflows or instructions
5. **Commit all changes together**

### When You Receive Instructions to Update claude.md

**MANDATORY STEPS:**

1. **Update claude.md** with the new instructions
2. **Update document-index.md**:
   - Update the "Last Updated" timestamp for claude.md
   - Add any new document types to the registry
3. **Review ALL documents** listed in document-index.md:
   - Check if the new instructions affect existing documents
   - Update documents that need to align with new instructions
   - Add cross-references where needed
4. **Verify consistency** across the entire documentation system
5. **Commit all changes together**

---

## Documentation Structure

### Primary Documents (Requirements & Planning)

1. **README.md** - Project overview, quick start, high-level features
2. **REQUIREMENTS.md** - Core product requirements, MVP features, implementation phases
3. **PROJECT_STRUCTURE.md** - Technical architecture, file organization, data flow
4. **WEBSITE_REQUIREMENTS.md** - Marketing website specifications, target audience, messaging
5. **BACKLOG.md** - Future feature ideas (94+ features), prioritization framework
6. **document-index.md** - Central registry of all documents (THIS IS THE SOURCE OF TRUTH)
7. **claude.md** - This file - instructions for AI agents working on the project

### Future Documents (As Needed)

- **API_REFERENCE.md** - Detailed API documentation (when product is built)
- **CONTRIBUTING.md** - Guidelines for contributors
- **CHANGELOG.md** - Version history and release notes
- **DEPLOYMENT.md** - Deployment instructions and infrastructure
- **TESTING.md** - Testing strategy and test cases
- **SECURITY.md** - Security considerations and vulnerability reporting

---

## Document Cross-Reference Rules

### Always Maintain Bidirectional Links

If Document A references Document B, consider if Document B should reference Document A.

**Example:**
- `REQUIREMENTS.md` links to `WEBSITE_REQUIREMENTS.md` ✓
- `WEBSITE_REQUIREMENTS.md` should link back to `REQUIREMENTS.md` ✓

### Use Consistent Link Format

```markdown
See [DOCUMENT_NAME.md](./DOCUMENT_NAME.md) for details.

For specific sections:
See [Section Name in DOCUMENT_NAME.md](./DOCUMENT_NAME.md#section-anchor)
```

### "Related Documentation" Sections

Every major document should have a "Related Documentation" section listing:
- Parent documents (higher level)
- Child documents (more detailed)
- Sibling documents (same level, related topics)

---

## Git Workflow

### Branching Strategy

**Current Branch:** `claude/share-requirements-01TsYnVAHahuv1kMGbWxm97a`

**Branch Naming Convention:**
- `claude/[task-description]-[session-id]` - For AI-generated work
- `feature/[feature-name]` - For human-developed features
- `docs/[doc-update]` - For documentation updates
- `website/[page-or-feature]` - For marketing website work

### Commit Message Guidelines

**Format:**
```
[Category] Brief description

Detailed explanation:
- What changed
- Why it changed
- Impact on other documents/systems

Related documents updated:
- document-index.md
- REQUIREMENTS.md
- etc.
```

**Categories:**
- `[Docs]` - Documentation updates
- `[Feature]` - New feature implementation
- `[Fix]` - Bug fixes
- `[Refactor]` - Code refactoring
- `[Test]` - Test additions/updates
- `[Website]` - Marketing website changes
- `[Meta]` - Project structure, build config, etc.

### Atomic Commits for Documentation

When updating documentation, **always commit related changes together**:

```bash
# Good: All related doc updates in one commit
git add document-index.md REQUIREMENTS.md BACKLOG.md
git commit -m "[Docs] Add new feature to backlog and update requirements"

# Bad: Separate commits that break consistency temporarily
git add BACKLOG.md
git commit -m "[Docs] Add feature to backlog"
git add REQUIREMENTS.md
git commit -m "[Docs] Update requirements"  # <- Index is out of sync between commits!
```

---

## Development Workflow

### Current Phase: Parallel Development

**Track 1: Marketing Website** (Priority for early validation)
- Framework: Next.js 14 (App Router)
- Styling: Tailwind CSS
- Components: shadcn/ui
- Deployment: Vercel (free tier)
- Timeline: 2 weeks

**Track 2: Product Development** (Core DOMideas library)
- Framework: Vanilla TypeScript (framework-agnostic)
- Build: Vite
- Testing: Vitest + Playwright
- Timeline: 6 weeks (after or parallel with website)

### When Starting a New Phase

1. **Review all documentation** to understand current state
2. **Check document-index.md** for the latest version of each document
3. **Read this file (claude.md)** for any updated instructions
4. **Create a new branch** following naming convention
5. **Update REQUIREMENTS.md** to mark phase as "in progress"
6. **Update document-index.md** when you create new files
7. **Commit regularly** with descriptive messages

---

## Code Organization Instructions

### When Creating New Code Files

1. **Follow PROJECT_STRUCTURE.md** for file organization
2. **Update PROJECT_STRUCTURE.md** if you deviate from the plan (with justification)
3. **Add JSDoc comments** or TypeScript doc comments for public APIs
4. **Update document-index.md** to include new code documentation files

### When Creating New Components (Website)

```
website/
├── src/
│   ├── app/                    # Next.js app router pages
│   ├── components/             # Reusable components
│   │   ├── ui/                 # shadcn/ui components
│   │   ├── sections/           # Landing page sections
│   │   └── layout/             # Layout components (header, footer)
│   ├── lib/                    # Utility functions
│   └── styles/                 # Global styles
```

### When Creating Product Code

```
packages/domideas/
├── src/
│   └── lib/
│       └── designer-mode/
│           ├── index.ts
│           ├── overlay.ts
│           ├── components/
│           ├── detection/
│           ├── diff/
│           └── utils/
```

---

## AI-Specific Instructions

### For Claude Code (or similar AI agents)

When you're asked to work on this project:

1. **Start by reading these files in order:**
   - `claude.md` (this file) - Understand the workflow
   - `document-index.md` - See what documents exist
   - `REQUIREMENTS.md` - Understand what we're building
   - Any specific documents relevant to your task

2. **Before making changes:**
   - Announce which documents you plan to modify
   - Explain how they relate to each other
   - Confirm the user agrees with the approach

3. **After making changes:**
   - List all documents you modified
   - Confirm they're all in sync
   - Update document-index.md timestamps
   - Commit atomically

4. **Communication style:**
   - Be direct and concise (this is a CLI tool)
   - Avoid excessive emojis unless user requests them
   - Focus on technical accuracy over validation
   - Propose solutions, don't just describe problems

### Context Sharing Between Sessions

When starting a new session:

1. **User should provide context** by sharing:
   - Current branch name
   - Current phase (from REQUIREMENTS.md)
   - Specific task or goal

2. **You should respond** by:
   - Reading claude.md (this file)
   - Reading document-index.md
   - Confirming your understanding of the current state
   - Proposing a plan before executing

### Handling Conflicts or Ambiguity

If you notice:
- **Conflicting information** between documents → Point it out, propose a fix
- **Missing cross-references** → Add them
- **Outdated timestamps** → Update them
- **Unclear requirements** → Ask for clarification before proceeding

---

## Quality Standards

### Documentation Quality

Every document should:
- Have a clear purpose stated at the top
- Use consistent markdown formatting
- Include a "Last Updated" timestamp (in document-index.md)
- Cross-reference related documents
- Be readable by both humans and AI agents

### Code Quality

Every code file should:
- Follow the project's TypeScript style guide
- Include JSDoc/TSDoc comments for public APIs
- Have corresponding tests (unit or integration)
- Be referenced in PROJECT_STRUCTURE.md

### Commit Quality

Every commit should:
- Have a descriptive message explaining WHY, not just WHAT
- Include all related changes (atomic commits for related files)
- Pass linting and tests (once set up)
- Update documentation if behavior changes

---

## Testing Strategy

### Documentation Testing (Manual)

Before committing documentation changes:

1. **Link validity:**
   ```bash
   # Check for broken internal links
   grep -r "\[.*\](\.\/.*\.md)" *.md | while read line; do
     # Verify linked file exists
   done
   ```

2. **Consistency check:**
   - All documents mentioned in document-index.md exist?
   - All timestamps in document-index.md are accurate?
   - All cross-references are bidirectional?

3. **Readability:**
   - Can a new contributor understand the project from README.md?
   - Are technical terms explained or linked?
   - Is the information architecture logical?

### Code Testing (When Applicable)

- Unit tests for utility functions
- Integration tests for component detection
- E2E tests for full workflow (edit → export → apply)
- Visual regression tests for website

---

## Deployment Instructions

### Marketing Website (Vercel)

**Setup (First Time):**
```bash
# Install Vercel CLI
npm i -g vercel

# Navigate to website directory
cd website

# Deploy
vercel
```

**Continuous Deployment:**
- Push to `main` branch → Auto-deploys to production
- Push to feature branch → Auto-creates preview deployment
- PR opened → Preview link added to PR comments

**Custom Domain (Future):**
1. Buy domain (e.g., domideas.com)
2. Add to Vercel project settings
3. Update DNS records as instructed
4. SSL auto-configured

### Product Package (NPM - Future)

**Publishing:**
```bash
cd packages/domideas
npm version [major|minor|patch]
npm publish
```

**Pre-publish checklist:**
- Tests passing
- Documentation updated
- CHANGELOG.md updated
- Version bumped in package.json

---

## Common Tasks Quick Reference

### Adding a New Feature to Backlog

1. Open `BACKLOG.md`
2. Add feature to appropriate category (High/Medium/Experimental)
3. Update feature count at bottom
4. Update `document-index.md` timestamp for BACKLOG.md
5. Commit: `[Docs] Add [feature name] to backlog`

### Creating a New Planning Document

1. Create the document with proper structure
2. Add "Related Documentation" section
3. Update `document-index.md` with new entry
4. Update `REQUIREMENTS.md` to link to new document (if relevant)
5. Update this file (`claude.md`) if it affects workflows
6. Commit all changes together

### Starting Website Development

1. Read `WEBSITE_REQUIREMENTS.md` thoroughly
2. Create `website/` directory
3. Initialize Next.js: `npx create-next-app@latest website --typescript --tailwind --app`
4. Set up project structure per requirements
5. Update `PROJECT_STRUCTURE.md` with website structure
6. Update `document-index.md` with any new docs (like website README)
7. Commit: `[Website] Initialize Next.js project`

### Starting Product Development

1. Read `REQUIREMENTS.md` and `PROJECT_STRUCTURE.md`
2. Create `packages/domideas/` directory
3. Initialize TypeScript project
4. Set up according to PROJECT_STRUCTURE.md
5. Create initial files (index.ts, overlay.ts, etc.)
6. Update `document-index.md` with any API documentation
7. Commit: `[Feature] Initialize DOMideas package`

---

## Troubleshooting

### "Documents are out of sync"

**Solution:**
1. Check git diff to see what changed
2. Read document-index.md to find related documents
3. Update all related documents to be consistent
4. Update timestamps in document-index.md
5. Commit all changes atomically

### "Can't find information about X"

**Solution:**
1. Check document-index.md for the most likely document
2. Use grep to search across all docs: `grep -r "search term" *.md`
3. If not found, ask user or check BACKLOG.md (might be a future feature)

### "Conflicting requirements between documents"

**Solution:**
1. Point out the conflict to the user
2. Ask for clarification on which is correct
3. Update all documents to be consistent
4. Update document-index.md timestamps
5. Commit with explanation of the conflict resolution

---

## Project-Specific Conventions

### Naming Conventions

**Files:**
- Documents: `UPPERCASE_NAME.md` (e.g., REQUIREMENTS.md)
- Code: `kebab-case.ts` (e.g., designer-mode.ts)
- Components: `PascalCase.tsx` (e.g., StylePanel.tsx)
- Tests: `*.test.ts` or `*.spec.ts`

**Variables/Functions:**
- TypeScript: `camelCase`
- Constants: `UPPER_SNAKE_CASE`
- Types/Interfaces: `PascalCase`
- CSS classes: `kebab-case`

**Governance Levels:**
- `GOVERNED` - Design system components
- `SHARED` - Reusable components
- `LOCAL` - Page-specific elements

### Terminology

Use consistent terminology across all documents:

- **Designer Mode** - The editing overlay (not "edit mode" or "visual mode")
- **Diff** - The AI-optimized output (not "export" or "report")
- **Component Detection** - The process of identifying React/Vue components
- **Governance Assessment** - Classifying components as GOVERNED/SHARED/LOCAL
- **AI Agent** - Tools like Claude Code, Copilot (not "AI" alone)
- **Marketing Website** - The public-facing site (not "landing page" or "website")
- **Product** - The DOMideas library itself (not "tool" or "app")

---

## Success Criteria

You're doing well if:

✅ All documents listed in document-index.md actually exist
✅ All timestamps in document-index.md are accurate
✅ Cross-references are bidirectional and working
✅ No conflicting information between documents
✅ New contributors can onboard using just the documentation
✅ AI agents can resume work from a new session seamlessly
✅ Commits are atomic and include all related doc updates
✅ The documentation tells a coherent story about the project

You need to improve if:

❌ Documents contradict each other
❌ Links are broken or outdated
❌ document-index.md is missing documents
❌ Timestamps are wrong or missing
❌ Changes aren't committed atomically
❌ New documents aren't cross-referenced
❌ Code doesn't match PROJECT_STRUCTURE.md

---

## Version History of This File

**2025-11-15** - Initial creation
- Established documentation maintenance workflow
- Defined mandatory steps for document updates
- Created cross-reference rules
- Added project-specific conventions

**[Future updates will be listed here]**

---

## Questions or Improvements?

If you (as an AI agent) notice:
- Missing instructions that would be helpful
- Ambiguous guidelines
- Conflicts in this file
- Better ways to structure the documentation

→ Point it out to the user and suggest improvements
→ This file should evolve as the project grows

---

**Remember: Documentation is code. Keep it consistent, tested, and up-to-date.**
